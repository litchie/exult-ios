#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Opcode flags
// Just a 16bit word
#define IMMED					0
// Will print a part of data string as comment
#define	DATA_STRING				1
// Will add command offset before printing
#define	RELATIVE_JUMP			2
// Will print third byte as decimal after comma
#define CALL					4
// Will print in square brackets
#define VARREF					8
// Will print in square brackets with "flag:" prefix
#define FLGREF					16
// Call of usecode function using extern table
#define EXTCALL					32
// An immediate op. and then a rel. jmp address:  JSF
#define IMMED_AND_RELATIVE_JUMP			64
// Just x bytes
#define BYTES					128
// Just a byte
#define BYTE					256

// Opcode descriptor
typedef struct _opcode_desc
{
	// Mnemonic - NULL if not known yet
	unsigned char* mnemonic;
	// Number of operand bytes
	int nbytes;
	// Type flags
	unsigned char type;
} opcode_desc;

// Opcode table
static opcode_desc opcode_table[] =
{
	{ NULL, 0, 0 },						// 00
	{ NULL, 0, 0 },						// 01
	{ "db 2\t???", 10, BYTES },				// 02
	{ NULL, 0, 0 },						// 03
	{ "je", 2, RELATIVE_JUMP },				// 04 JSF
	{ "jne", 2, RELATIVE_JUMP },				// 05
	{ "jmp", 2, RELATIVE_JUMP },				// 06
	{ "cmps", 4, IMMED_AND_RELATIVE_JUMP },			// 07 JSF
	{ NULL, 0, 0 },						// 08
	{ "add", 0, 0 },					// 09
	{ "sub", 0, 0 },					// 0a
	{ "div", 0, 0 },					// 0b
	{ "mul", 0, 0 },					// 0c
	{ "mod", 0, 0 },					// 0d
	{ "and", 0, 0 },					// 0e
	{ "or", 0, 0 },						// 0f
	{ "not", 0, 0 },					// 10
	{ NULL, 0, 0 },						// 11
	{ "pop", 2, VARREF },					// 12
	{ "push\ttrue", 0, 0 },					// 13
	{ "push\tfalse", 0, 0 },				// 14
	{ NULL, 0, 0 },						// 15
	{ "cmpgt", 0, 0 },					// 16
	{ "cmpl", 0, 0 },					// 17
	{ "cmpge", 0, 0 },					// 18
	{ "cmple", 0, 0 },					// 19
	{ "cmpne", 0, 0 },					// 1a
	{ NULL, 0, 0 },						// 1b
	{ "addsi", 2, DATA_STRING },				// 1c
	{ "pushs", 2, DATA_STRING },				// 1d
	{ "arrc", 2, IMMED },					// 1e
	{ "pushi", 2, IMMED },					// 1f
	{ NULL, 0, 0 },						// 20
	{ "push", 2, VARREF },					// 21
	{ "cmpeq", 0, 0 },					// 22
	{ NULL, 0, 0 },						// 23
	{ "call", 2, EXTCALL },					// 24
	{ "ret", 0, 0 },					// 25
	{ "aidx", 2, VARREF },					// 26
	{ NULL, 0, 0 },						// 27
	{ NULL, 0, 0 },						// 28
	{ NULL, 0, 0 },						// 29
	{ NULL, 0, 0 },						// 2a
	{ NULL, 0, 0 },						// 2b
	{ "db 2c\t???", 0, 0 },					// 2c
	{ "setr", 0, 0 },					// 2d
	{ "sloop", 0, 0 },					// 4e
	{ "addsv", 2, VARREF },					// 2f
	{ "in", 0, 0 },						// 30
	{ "db 31\t???", 4, BYTES },				// 31
	{ "rts", 0, 0 },					// 32
	{ "say", 0, 0 },					// 33
	{ NULL, 0, 0 },						// 34
	{ NULL, 0, 0 },						// 35
	{ NULL, 0, 0 },						// 36
	{ NULL, 0, 0 },						// 37
	{ "callis", 3, CALL },					// 38
	{ "calli", 3, CALL },					// 39
	{ NULL, 0, 0 },						// 3a
	{ NULL, 0, 0 },						// 3b
	{ NULL, 0, 0 },						// 3c
	{ NULL, 0, 0 },						// 3d
	{ "push\titemref", 0, 0 },				// 3e
	{ "abrt", 0, 0 },					// 3f
	{ "db 40\t???", 0, 0 },					// 40
	{ NULL, 0, 0 },						// 41
	{ "pushf", 2, FLGREF },					// 42
	{ "popf", 2, FLGREF },					// 43
	{ "pushw", 1, BYTE },					// 44
	{ "db 45\t???", 1, BYTES },				// 45
	{ "db 46\t???\n\t\t\tdw", 2, IMMED },			// 46
	{ "calle",2,IMMED },					// 47
	{ "push\teventid", 0, 0 },				// 48
	{ NULL, 0, 0 },						// 49
	{ "arra", 0, 0 },					// 4a
	{ "db 4b\t???", 0, 0 }					// 4b
};

// Embedded function table
static const char* func_table[] = 
{
	NULL,							// 0
	NULL,							// 1
	NULL,							// 2
	"SwitchTalkTo",						// 3
	"HideNPC",						// 4
	"AddAnswer",						// 5
	"RemoveAnswer",						// 6
	"SaveAnswers",						// 7
	"RestoreAnswers",					// 8
	NULL,							// 9
	"GetAnswer",						// a
	NULL,							// b
	"AskNumber",						// c
	"SetItemType",						// d
	NULL,							// e
	NULL,							// f
	"Random2",						// 10
	"GetItemType",						// 11
	"GetItemFrame",						// 12
	"SetItemFrame",						// 13
	"GetItemQuality",					// 14
	NULL,							// 15
	NULL,							// 16
	NULL,							// 17
	NULL,							// 18
	NULL,							// 19
	NULL,							// 1a
	NULL,							// 1b
	NULL,							// 1c
	NULL,							// 1d
	NULL,							// 1e
	NULL,							// 1f
	"GetNPCProperty",					// 20
	"SetNPCProperty",					// 21
	NULL,							// 22
	"GetPartyMembers",					// 23
	NULL,							// 24
	NULL,							// 25
	NULL,							// 26
	"GetPlayerName",					// 27
	NULL,							// 28
	NULL,							// 29
	"GetContainerItems",					// 2a
	NULL,							// 2b
	NULL,							// 2c
	NULL,							// 2d
	"PlayMusic",						// 2e
	"NPCInParty",						// 2f
	NULL,							// 30
	NULL,							// 31
	"DisplaySign",						// 32
	"ItemSelectModal",					// 33
	NULL,							// 34
	NULL,							// 35
	NULL,							// 36
	NULL,							// 37
	"GetTimeHour",						// 38
	"GetTimeMinute",					// 39
	NULL,							// 3a
	NULL,							// 3b
	NULL,							// 3c
	NULL,							// 3d
	NULL,							// 3e
	NULL,							// 3f
	"ItemSay",						// 40
	NULL,							// 41
	NULL,							// 42
	NULL,							// 43
	NULL,							// 44
	NULL,							// 45
	NULL,							// 46
	NULL,							// 47
	NULL,							// 48
	NULL,							// 49
	NULL,							// 4a
	NULL,							// 4b
	NULL,							// 4c
	NULL,							// 4d
	NULL,							// 4e
	NULL,							// 4f
	NULL,							// 50
	NULL,							// 51
	NULL,							// 52
	NULL,							// 53
	NULL,							// 54
	NULL,							// 55
	NULL,							// 56
	NULL,							// 57
	NULL,							// 58
	NULL,							// 59
	"IsPlayerFemale",					// 5a
	NULL,							// 5b
	NULL,							// 5c
	"StartEndgame",						// 5d
	"ArraySize",						// 5e
	NULL,							// 5f
	NULL,							// 60
	NULL,							// 61
	NULL,							// 62
	NULL,							// 63
	NULL,							// 64
	NULL,							// 65
	NULL,							// 66
	NULL,							// 67
	"DetectMouse",						// 68
	NULL,							// 69
	NULL,							// 6a
	NULL,							// 6b
	NULL,							// 6c
	NULL,							// 6d
	NULL,							// 6e
	NULL,							// 6f
	NULL,							// 70
	NULL,							// 71
	NULL,							// 72
	NULL,							// 73
	NULL,							// 74
	NULL,							// 75
	NULL,							// 76
	NULL,							// 77
	NULL,							// 78
	NULL,							// 79
	NULL,							// 7a
	NULL,							// 7b
	NULL,							// 7c
	NULL,							// 7d
	NULL,							// 7e
	NULL,							// 7f
	NULL,							// 80
	NULL,							// 81
	NULL,							// 82
	NULL,							// 83
	NULL,							// 84
	NULL,							// 85
	NULL,							// 86
	NULL,							// 87
	NULL,							// 88
	NULL,							// 89
	NULL,							// 8a
	NULL,							// 8b
	NULL,							// 8c
	NULL,							// 8d
	NULL,							// 8e
	NULL,							// 8f
	NULL,							// 90
	NULL,							// 91
	NULL,							// 92
	NULL,							// 93
	NULL,							// 94
	NULL,							// 95
	NULL							// 96
};

// Prints module's data segment
void printdataseg(FILE* f, unsigned short ds)
{
	long pos;
	unsigned short off = 0;
	unsigned char* p;	unsigned char* pp;
	unsigned char* tempstr,*tempstr2;
	tempstr = malloc(60 + 1);
	pos = ftell(f);
	pp = p = malloc(ds);
	fread(p, 1, ds, f);
	fseek(f, pos, SEEK_SET);
	printf("\t\t.data\n");
	while( off < ds )
	{
		int len;
		unsigned short localoff = 0;
		while( len = ( strlen(pp) > 60 ) ? 60 : strlen(pp) )
		{
			memcpy(tempstr, pp, len);
			tempstr[len] = '\0';
			if (!localoff)
				printf("L%04X:",off);
			  while (strchr(tempstr,13))
			  {
			   tempstr2=strchr(tempstr,13)+2;
 			   tempstr[strchr(tempstr,13) - (char *) tempstr]=0;
			   printf("\tdb\t\'%s\'\n\tdb\t0d\n\tdb\t0a\n", tempstr);
			   strcpy(tempstr,tempstr2);
			  }
			if (tempstr)
				printf("\tdb\t\'%s\'\n", tempstr);
			localoff += len; 
			pp += len;
		}
		pp++;
		printf("L%04X:\tdb\t00\n", off+localoff,tempstr);
		off += localoff + 1;
	}
	free(p);
	free(tempstr);
}

// Prints single opcode
// Return number of bytes to advance the code pointer
// Prints first characters of strings referenced
unsigned short print_opcode(unsigned char* ptrc, unsigned short coffset,
	unsigned char* pdataseg,unsigned short* pextern,
	unsigned short externsize)
{
	unsigned short nbytes;
	unsigned short i;
	// Find the description
	opcode_desc* pdesc = ( *ptrc >= ( sizeof(opcode_table) / sizeof( opcode_desc ) ) ) ?
							NULL : opcode_table + ( *ptrc );
	if( pdesc && ( pdesc->mnemonic == NULL ) )
	{
		printf("Unknown opcode: %x\n",*ptrc);
		// Unknown opcode
		pdesc = NULL;
	}
	// Number of bytes to print
	nbytes = pdesc ? ( pdesc->nbytes + 1 ) : 1;
	// Print label
	printf("%04X: ", coffset);
	// Print bytes
	for( i = 0; i < nbytes; i++ )
		printf("%02X ", ptrc[i]);
	// Print mnemonic
	if( nbytes < 4 )
		printf("\t");
        if (pdesc)
		printf("\t%s", pdesc->mnemonic);
	else
		printf("\tdb %x\t???",ptrc[0]);
	// Print operands if any
	if( ( nbytes == 1 ) || ( pdesc == NULL && pdesc->type == 0) )
	{
		printf("\n");
		return nbytes;
	}
	switch( pdesc->type )
	{
	case BYTE:
		printf("\t%x\n",*(unsigned char*)(ptrc+1));
		break;
	case BYTES:
		for ( i = 1; i < nbytes; i++)
			printf("\n%04X:\t\t\tdb %x",coffset+i,ptrc[i]);
		printf("\n");
		break;
	case IMMED:
		// Print immediate operand
		printf("\t%04XH\t\t\t; %d\n", *(unsigned short*)( ptrc + 1 ), *(short*)( ptrc + 1 ));
		break;
	case DATA_STRING:
		{
			unsigned char* pstr;
			int len;
			// Print data string operand
			pstr = pdataseg + *(unsigned short*)( ptrc + 1 );
			len = strlen(pstr);
			if( len > 20 )
				len = 20 - 3;
			printf("\tL%04X\t\t\t; ", *(unsigned short*)( ptrc + 1 ));
			for( i = 0; i < len; i++ )
				printf("%c", pstr[i]);
			if( len < strlen(pstr) )
				// String truncated
				printf("...");
			printf("\n");
		}
		break;
	case RELATIVE_JUMP:
		// Print jump desination
		printf("\t%04X\n", *(short*)( ptrc + 1 ) + (short)coffset + 3);
		break;
	case IMMED_AND_RELATIVE_JUMP:	/* JSF */
		printf("\t%04XH, %04X\n", *(unsigned short*)( ptrc + 1 ),
				*(short*)( ptrc + 3 ) + (short)coffset + 5);
		break;
	case CALL:
		{
			// Print call operand
			unsigned short func = *(unsigned short*)( ptrc + 1 );
			if( ( func < ( sizeof(func_table) / sizeof(const char *) ) ) &&
				 func_table[func] )
				// Known function
				printf("\t_%s@%d\t\t; %04X\n", func_table[func], ptrc[3], func);
			else
				// Unknown function
				printf("\t%04X, %d\n", func, ptrc[3]);
		}
		break;
	case EXTCALL:
		{
			// Print extern call
			unsigned short externpos = *(unsigned short*)( ptrc + 1 );
			if( externpos < externsize )
				printf("\t[%04X]\t\t\t; %04XH\n", externpos, pextern[externpos]);
			else
				printf("\t[%04X]\t\t\t; ????\n", externpos);
		}
		break;
	case VARREF:
		// Print variable reference
		printf("\t[%04X]\n", *(unsigned short*)( ptrc + 1 ));
		break;
	case FLGREF:
		// Print global flag reference
		printf("\tflag:[%04X]\n", *(unsigned short*)( ptrc + 1 ));
		break;
	default:
		// Unknown type
		printf("\n");
		break;
	}
	return nbytes;
}

void printcodeseg(FILE* f, unsigned short ds, unsigned short s)
{
	long pos;
	unsigned short size;
	unsigned short externsize;
	unsigned short i;
	unsigned short offset;
	unsigned short nbytes;
	unsigned char* p;
	unsigned char* pp;
	unsigned char* pdata;
	unsigned short* pextern;
	pos = ftell(f);
	size = s - ds - sizeof(unsigned short);
	pp = p = malloc(size);
	pdata = malloc(ds);
	fread(pdata, 1, ds, f);
	printf("\t\t.code\n");
	fread(p, 1, size, f);
	fseek(f, pos, SEEK_SET);
	// Print code segment header
	if( size < 3 * sizeof(unsigned short) )
	{
		printf("Code segment bad!\n");
		free(p);
		free(pdata);
		return;
	}
	// Print argument counter
	printf("\t\t.argc %04XH\n", *(unsigned short*)pp);
	pp += sizeof(unsigned short);
	// Print locals counter
	printf("\t\t.localc %04XH\n", *(unsigned short*)pp);
	pp += sizeof(unsigned short);
	// Print externs section
	externsize = *(unsigned short*)pp;
	printf("\t\t.externsize %04XH\n", externsize);
	pp += sizeof(unsigned short);
	if( size < ( ( 3 + externsize ) * sizeof(unsigned short) ) )
	{
		printf("Code segment bad!\n");
		free(p);
		free(pdata);
		return;
	}
	size -= ( ( 3 + externsize ) * sizeof(unsigned short) );
	pextern = (unsigned short*)pp;
	for( i = 0; i < externsize; i++ )
	{
		printf("\t\t.extern %04XH\n", *(unsigned short*)pp);
		pp += sizeof(unsigned short);
	}
	offset = 0;
	// Print opcodes
	while( offset < size )
	{
		nbytes = print_opcode(pp, offset, pdata, pextern, externsize);
		pp += nbytes;
		offset += nbytes;
	}
	free(p);
	free(pdata);
}

void printfunc(FILE* f, long func, int i)
{
	unsigned short s, ds, funcnum;	
	long off, bodyoff;
	// Save start offset
	off = ftell(f);
	// Read function header
	fread(&funcnum, sizeof(unsigned short), 1, f);
	fread(&s, sizeof(unsigned short), 1, f);
	// Save body offset
	bodyoff = ftell(f);
	fread(&ds, sizeof(unsigned short), 1, f);
	if( func == -1 )
		printf("\tFunction #%d (%04XH), offset = %08lx, size = %04x, data = %04x\n", i,
			funcnum, off, s, ds);
	if( funcnum == func )
	{
		printf("\t\t.funcnumber\t%04XH\n", funcnum);
		// Dump function contents
		printdataseg(f, ds);
		printcodeseg(f, ds, s);
	}
	// Seek back, then to next function
	fseek(f, bodyoff, SEEK_SET);
	fseek(f, s, SEEK_CUR);
}

void main(int ac, char** av)
{
	unsigned long func = -1;
	long sz;
	int i = 0;
	FILE* f;
	f = fopen("static/usecode", "rb");
	if( f == NULL )
	{
		fprintf(stderr,"Failed to open usecode file\n\n");
		return;
	}
	fseek(f, 0, SEEK_END);
	sz = ftell(f);
	fseek(f, 0, SEEK_SET);
	if( ac > 1 )
	{
		char* stopstr;
		func = strtoul(av[1], &stopstr, 16);
	}
	while( ftell(f) < sz )
	{		
		printfunc(f, func, i);
		i++;
	}
	if( func == -1 )
	{
		if( ftell(f) != sz )
			fprintf(stderr,"Problem, tell = %d!\n", ftell(f));
		printf("Functions: %d\n", i);
	}
	fclose(f);
}
