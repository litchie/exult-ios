/*
 	Ultima 7 flic player (C) 2000 IT-HE Software

	'Do what thou wilt; that shall be the whole of the Law'

	To compile this (as it stands, needs Allegro):
	gcc u7play.c itheflic.c -lalleg -o u7play.exe

*/

#include <stdio.h>
#include <allegro.h>

extern int play_flic(char *filename, int offset, char *scr, char *pal);

BITMAP *swapscr;
unsigned char fli_pal[768];


main(int argc,char *argv[])
{
unsigned int ctr,ctr2;
char *swapscreen;

/* Do checking */

if(argc<3)
	{
        printf("u7play - U7 animation player\n");
        printf("Syntax:\n");
	printf("JFP <flic name> <hex offset> [hex offset2] ....\n");
	exit(1);
	}

/* Set up Allegro */

allegro_init();
set_gfx_mode(GFX_AUTODETECT,320,200,0,0);

/* Create a sprite.  The actual buffer will be our virtual screen */

swapscr = create_bitmap(320,200);
if(!swapscr)
        {
        printf("Oops\n");
	exit(1);
        }

/* Allegro-based hack */

swapscreen = swapscr->line[0];


/*
You probably want something more like this:

swapscreen = malloc(64000);
*/


/* Take each of the offsets, convert them from hex and play them */

for(ctr=2;ctr<argc;ctr++)
	{
	sscanf(argv[ctr],"%x",&ctr2);
	if(play_flic(argv[1],ctr2,(unsigned char *)swapscr->line[0],fli_pal) <0)
		{
/*		printf("Bad magic in offset 0x%x\n",ctr2);*/
		asm("int $3");
		}
	}

/* That's all folks! */
        
}

/*
 *      Update the display with the current frame
 *	In this implementation, swap_screen is a pointer to buf inside swapscr
 */

void fli_update_frame()
{
blit(swapscr,screen,0,0,0,0,320,200);

/*
I hope you don't have to do something slow like this:

unsigned char *ptr = swap_screen;

for(y=0;y<200;y++)
   for(x=0;x<320;x++)
       putpixel(x,y,*ptr++);
*/

}

/*
 *      Update the palette of 768 bytes (256 rgb triplets)
 *	Convert it to Allegro format and display
 */

void fli_update_pal()
{
int ctr,ptr;
PALETTE pal;
ptr=0;
for(ctr=0;ctr<256;ctr++)
	{
        pal[ctr].r = fli_pal[ptr++];
        pal[ctr].g = fli_pal[ptr++];
        pal[ctr].b = fli_pal[ptr++];
        }
set_palette(pal);


/*
Yours might be something as simple as:

pal_set(fli_pal);

*/
}

