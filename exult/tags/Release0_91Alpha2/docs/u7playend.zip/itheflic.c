/*
	ITG 3.00 - Internal flic engine (C) 1994 IT-HE Software
                   DJGPP/Allegro port (C) 2000 IT-HE Software

	'Do what thou wilt; that shall be the whole of the Law'
*/

#include <stdio.h>
#include <stdlib.h>
#include <mem.h>
#include <time.h>

/* User functions */

extern void fli_update_pal();
extern void fli_update_frame();

/* Private stuff */

static int offptr;
static long chunksize;
static FILE *fp;

static unsigned char *swap_screen;
static unsigned char *fli_pal;
static void fli_col64();
static void fli_col256();
static void fli_LC();
static void fli_brun();
static void fli_copy();
static void choose_method(unsigned short method);

struct Fli_head {
	unsigned long size;
	unsigned short magic;
	unsigned short frames;
	unsigned short width;
	unsigned short height;
	unsigned short depth;
	unsigned short flags;
	unsigned short speed;
	unsigned char nothing[110];
} fli_head;

struct Frame_header
	{
	unsigned long size;	/* size of chunk coming */
	unsigned short F1FA;	/* a file sig.	always f1fa */
	unsigned short chunks;	/* number of little chunks coming */
	long nothing;		/* blank */
	long more_nothing;	/* blank */
	} frame_header;

static int read_Flihead(struct Fli_head *head,FILE *fp);
static int read_Frameheader(struct Frame_header *head,FILE *fp);

/* Code starts: */

/*
 *	This is the public function
 */

int play_flic(char *filename, unsigned int offset, unsigned char *screen, unsigned char *palbuf)
{
unsigned int ctr,ctr2;
time_t start;
double speed;
unsigned short type;

fp=fopen(filename,"rb");
if(!fp)
	return -1;

fseek(fp,offset,SEEK_SET);

swap_screen=screen;
fli_pal=palbuf;

if(!read_Flihead(&fli_head,fp))
	{
        fclose(fp);
        return -2;
//	printf("Bad Magic '%x' : not a flic.\n",fli_head.magic);
	}

speed=fli_head.speed;
speed/=80;
speed*=CLK_TCK;

ctr=0;
while(ctr<fli_head.frames/* && !kbhit()*/)
	{
        ctr++;
        start=clock();
	offptr = ftell(fp);

	if(!read_Frameheader(&frame_header,fp))
		{
	        fclose(fp);
	        return -2;
//		printf("Bad Magic '%x' in chunk.\n",frame_header.F1FA);
		}

        ctr2=0;
        while(ctr2<frame_header.chunks/*&& !kbhit()*/)
		{
		ctr2++;
                fread(&chunksize,1,4,fp);
                fread(&type,1,2,fp);
		choose_method(type);
		}

        /* Variable delay */
	while (clock()-start< speed/* && !kbhit()*/);
	}
        
return 0;
}

/*
 *  Player modules
 */

/* Choose the appropriate decoding method from the functions below */

void choose_method(unsigned short method)
{
switch(method)
	{
	case 4:
	fli_col256();		/* type 1 palette - done */
	break;

	case 11:
	fli_col64();		/* type 2 palette - done */
	break;

	case 12:		/* delta - done */
	fli_LC();
	break;

	case 13:		/* it's black.	- done */
        memset(swap_screen,0,64000);
	break;

	case 15:		/* byte Run-length - done */
	fli_brun();
	break;

	case 16:		/* uncompressed - done */
	fli_copy();
	break;

	default:
	printf("Unknown compression method %d\n",method);
	break;
	}
return;
}

/* set palette colours for 256-based palette (8-bit RGB) */

void fli_col256()
{
unsigned short packets,ctr,ctr2,number;
unsigned char skip_count,r,g,b;
int index=0;

fread(&packets,1,2,fp);

for(ctr=0;ctr<packets;ctr++)
	{
	skip_count=getc(fp);
	index+=skip_count;
	number=getc(fp);
	if(number==0)
		number=256;
        number*=3;
	for(ctr2=0;ctr2<number;ctr2++)
                fli_pal[index++]=(getc(fp)>>2);
	}
fli_update_pal();
}

/* set palette colours for 64-based palette (6-bit RGB) */

void fli_col64()
{
unsigned short packets,ctr,ctr2,number;
unsigned char skip_count,r,g,b;
int index=0;

fread(&packets,1,2,fp);

for(ctr=0;ctr<packets;ctr++)
	{
	skip_count=getc(fp);
	index+=skip_count;
	number=getc(fp);
	if(number==0)
		number=256;
        number*=3;

	for(ctr2=0;ctr2<number;ctr2++)
                fli_pal[index++]=getc(fp);
	}
fli_update_pal();
}

/* copy uncompressed flic data */

void fli_copy()
{
fread(swap_screen,chunksize - 6,1,fp);
fli_update_frame();
}

/* decompress flic data - byte runlength */

void fli_brun()
{
signed char packettype;
unsigned char packlen,pk,ctr;
int width=0,height=0;
char *sptr;

sptr=swap_screen;

for(height=0;height<200;height++)
	{
	getc(fp);
	width=0;
	while (width<320)
		{
		packettype=getc(fp);
		if(packettype<0)
			{
			packlen=abs(packettype);
			for(ctr=0;ctr<packlen;ctr++)
				{
				*sptr++=getc(fp);
				width++;
				}
			}
		else
			{
			packlen=abs(packettype);
			pk=getc(fp);
			for(ctr=0;ctr<packlen;ctr++)
				{
				*sptr++=pk;
				width++;
				}
			}
		}
	}
fli_update_frame();
fseek(fp,frame_header.size+offptr,SEEK_SET);
return;
}

/* decompress 'LC' data - byte runlength */

void fli_LC()
{
short y_off,no_of_y;
int ctr,ctr2,x,y,x_off,no_of_packs,runlen;
char pk;
signed char packettype;
unsigned char *sptr;

fread(&y_off,1,2,fp);
fread(&no_of_y,1,2,fp);
y=y_off;
for(ctr=0;ctr<no_of_y;ctr++)
	{
	no_of_packs=getc(fp);
        if(no_of_packs!=0)
        	{
		x_off=getc(fp);
		x=x_off;
                }
	for(ctr2=0;ctr2<no_of_packs;ctr2++)
		{
		packettype=getc(fp);
		if(packettype>0)
			{
			runlen=abs(packettype);
                        sptr=swap_screen+((320*y)+x);
                        fread(sptr,1,runlen,fp);
                        x+=runlen;
			}
		else
			{
			runlen=abs(packettype);
			pk=getc(fp);
                        sptr=swap_screen+((320*y)+x);

                        memset(sptr,pk,runlen);
                        x+=runlen;
			}

                if(no_of_packs>1 && ctr2!=no_of_packs-1)
                	x+=getc(fp);
		}
	y++;
	}
fli_update_frame();
fseek(fp,frame_header.size+offptr,SEEK_SET);
return;
}

/* Read FLIC header and check the Magic */

int read_Flihead(struct Fli_head *head,FILE *fp)
{
fread(&head->size,1,4,fp);
fread(&head->magic,1,2,fp);
fread(&head->frames,1,2,fp);
fread(&head->width,1,2,fp);
fread(&head->height,1,2,fp);
fread(&head->depth,1,2,fp);
fread(&head->flags,1,2,fp);
fread(&head->speed,1,2,fp);
fread(&head->nothing,1,110,fp);

if(fli_head.magic !=0xaf11)
	return 0; /* Bad Magic */
return 1;
}

/* Read frame header and check the Magic */

int read_Frameheader(struct Frame_header *head,FILE *fp)
{
fread(&head->size,1,4,fp);
fread(&head->F1FA,1,2,fp);
fread(&head->chunks,1,2,fp);
fread(&head->nothing,1,4,fp);
fread(&head->more_nothing,1,4,fp);

if(fli_head.magic !=0xaf11)
	return 0; /* Bad Magic */
return 1;
}


